return {
  { 'NMAC427/guess-indent.nvim', opts = {} },

  {
    'lewis6991/gitsigns.nvim',
    ---@type Gitsigns.Config
    opts = {
      signs = {
        add          = { text = '+' },
        change       = { text = '~' },
        delete       = { text = '_' },
        topdelete    = { text = '‾' },
        changedelete = { text = '~' },
      },
    },
  },

  {
    'folke/which-key.nvim',
    event = 'VimEnter',
    ---@type wk.Opts
    opts = {
      delay = 0,
      icons = { mappings = vim.g.have_nerd_font },
      spec  = {
        { '<leader>s', group = '[S]earch',   mode = { 'n', 'v' } },
        { '<leader>t', group = '[T]oggle' },
        { '<leader>h', group = 'Git [H]unk', mode = { 'n', 'v' } },
        { 'gr',        group = 'LSP Actions', mode = { 'n' } },
      },
    },
  },
}
