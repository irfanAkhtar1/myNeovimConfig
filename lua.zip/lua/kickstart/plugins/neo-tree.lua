return {
  'nvim-neo-tree/neo-tree.nvim',
  version = '*',
  dependencies = {
    'nvim-lua/plenary.nvim',
    'nvim-tree/nvim-web-devicons',
    'MunifTanjim/nui.nvim',
  },
  lazy = false,
  keys = {
    { '\\', ':Neotree reveal<CR>', desc = 'NeoTree reveal', silent = true },
  },
  config = function()
    require('neo-tree').setup({
      filesystem = {
        window = {
          mappings = {
            ['\\'] = 'close_window',
            ['d'] = function(state)
              local node = state.tree:get_node()
              local path = node:get_id()
              local is_dir = node.type == 'directory'

              vim.ui.input({ prompt = 'Delete "' .. node.name .. '"? (y/n): ' }, function(input)
                if input ~= 'y' then
                  return
                end

                -- Escape single quotes for PowerShell string safety
                local safe_path = path:gsub("'", "''")

                local ps_cmd
                if is_dir then
                  ps_cmd = string.format(
                    "Add-Type -AssemblyName Microsoft.VisualBasic; "
                      .. "[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory("
                      .. "'%s', 'OnlyErrorDialogs', 'SendToRecycleBin', 'ThrowException')",
                    safe_path
                  )
                else
                  ps_cmd = string.format(
                    "Add-Type -AssemblyName Microsoft.VisualBasic; "
                      .. "[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile("
                      .. "'%s', 'OnlyErrorDialogs', 'SendToRecycleBin')",
                    safe_path
                  )
                end

                -- Write command to a temp .ps1 file instead of -Command string,
                -- avoids quoting/escaping issues with cmd.exe -> powershell.exe
                local tmp_script = vim.fn.tempname() .. '.ps1'
                local f = io.open(tmp_script, 'w')
                if f then
                  f:write(ps_cmd)
                  f:close()
                end

                local result = vim.fn.system({
                  'powershell',
                  '-NoProfile',
                  '-ExecutionPolicy', 'Bypass',
                  '-File', tmp_script,
                })

                os.remove(tmp_script)

                if vim.v.shell_error ~= 0 then
                  vim.notify(
                    'Delete failed: ' .. (result or 'unknown error'),
                    vim.log.levels.ERROR
                  )
                else
                  require('neo-tree.sources.manager').refresh('filesystem')
                end
              end)
            end,
          },
        },
      },
    })
  end,
}
